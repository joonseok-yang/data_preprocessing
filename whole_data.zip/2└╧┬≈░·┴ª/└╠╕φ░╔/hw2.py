#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']= False

sr = pd.Series([15,18,20,40,80,80,35,40,40,30], name= "제품관리")
sr.index = ['홍길동','이순신','임꺽정','정난정', '이이', '이황', '정도전', '김철수1', '김철수2','김철수3' ]


# In[ ]:





# In[ ]:





# In[ ]:


# mysr=pd.Series() # 공백 시리즈

def myinput() :    
    sr[input("제품명:")] = input("수량:")    
    
def myoutput() :    
    print("-"*30)
    print("%10s%10s"%('제품명','수량'))
    print("-"*30)
    for v,r in sr.items(): #tuple unpacking하기
            print("%10s%10d"%(v,r))
    myMain()
            
def search() :
    st = input("검색제품명입력:")
    print("-"*30)
    print("%10s%10s"%('제품명','수량'))
    print("-"*30)
    print (sr[sr.index.str.contains(st)])    
    #sr[st]
    
def mySort() :
    sr.sort_index() 

def myShowchart() :
    sr.plot(kind='bar')
    plt.show()     

def myend():
    print("끝")
    
def myMain():    
    print("제품수량관리")
    print("-"*30)    
    print("1. 입력")
    print("2. 출력")
    print("3. 검색")
    print("4. 정렬(제품명기준)")
    print("5. 차트보기(바차트)")
    print("6. 검색")    
    print("-"*30)    
    
    menu = {1:myinput, 2:myoutput, 3:search, 4:mySort, 5:myShowchart, 6:myend}
    rst = int(input("메뉴를 선택하세요::"))
    menu.get(rst)()

myMain()


# In[ ]:





# In[ ]:





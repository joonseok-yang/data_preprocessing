import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

def input_prod(sr):
    yn = ""
    while(yn != "n"):
        p_name = input("제품명:")
        p_num = int(input("수량:"))
        yn = input("계속입력(y/n)?")
        sr[p_name] = p_num

def print_series(sr):
    print("-"*30)
    print("%10s%10s" % ('제품', '수량'))
    print("-"*30)
    for i,v in sr.items():
        print("%10s%10s" % (i, v))

def search_series(sr):
    try:
        p_name = input("검색제품명입력:")
        print("-"*30)
        print("%10s%10s" % ('제품', '수량'))
        print("-"*30)
        print(print("%10s%10s" % (p_name, sr[p_name])))
    except:
        print("해당 제품 없음")

def sort_series(sr):
    print("-"*30)
    print("%10s%10s" % ('제품', '수량'))
    print("-"*30)
    for i,v in sr.sort_index().items():
        print("%10s%10s" % (i, v))

def show_chart(sr):
    sr.plot(kind='bar')
    plt.show()

def print_menu():
        print("제품수량관리")
        print("-----")
        print("1. 입력")
        print("2. 출력")
        print("3. 검색")
        print("4. 정렬(제품명기준)")
        print("5. 차트보기(바차트)")
        print("6. 종료")

if __name__ == "__main__":
    sr = pd.Series()

    while(1):
        print_menu()
        menu = int(input("메뉴를 선택하세요:"))
        if menu == 1:
            input_prod(sr)
        elif menu == 2:
            print_series(sr)
        elif menu == 3:
            search_series(sr)
        elif menu == 4:
            sort_series(sr)
        elif menu == 5:
            show_chart(sr)
        else:
            break




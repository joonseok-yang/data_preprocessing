#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False


# In[7]:


sr = pd.Series(name='수량')
sr.index.name='제품명'
sr['커피']=10

def input_data():
    name=input('제품명:')
    count=input('수량:')
    sr[name]=count
    
print('='*20)
print('1.입력')
print('2.출력')
print('3.검색')
print('4.정렬(제품명기준)')
print('5.챠트보기')
print('6.종료')
print('='*20)
menu=input('메뉴를 선택하세요:')

if menu=='1':
    input_data()
    data_input_repeat=input('계속입력(y/n)?')
    if data_input_repeat=='y':
        input_data()
    else:
        exit()
    
elif menu=='2':
    print('-'*30)
    print("%10s%10s"% ('제품명','수량'))
    print('-'*30)
    for i,v in sr.iteritems():
        print("%10s%10d"%(i,v))

elif menu=='3':
    item3=input('검색제품명입력:')
    print('-'*30)
    print("%10s%10s"% ('제품명','수량'))
    print('-'*30)    

elif menu=='4':
    item3=input('검색제품명입력:')
    print('-'*30)
    print("%10s%10s"% ('제품명','수량'))
    print('-'*30)  

else:
    print('잘못된 입력')


# In[9]:


sr.iteritems()


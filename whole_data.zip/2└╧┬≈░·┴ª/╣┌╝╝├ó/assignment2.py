import pandas as pd
import numpy
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

sr = pd.Series()

def pressInput():
    while(1):
        p = input('제품명:')
        n = int (input('수량:'))
        sr[p] = n
        if input('계속입력(y/n)?') == 'n':
            break

def pressOutput():
    print('-'*30)
    print('제품', ' '*4,'수량')
    print('-'*30)
    print(sr, end='\n\n\n')

def pressSearch():
    p = input('검색제품명입력:')
    print(sr[p], end='\n\n\n')

def pressSort():
    print(sr.sort_values(ascending=False), end='\n\n\n')

def pressChart():
    sr.plot(kind='bar')
    plt.show()

def pressExit():
    exit(0)

def main_menu():
    print('1. 입력')
    print('2. 출력')
    print('3. 검색')
    print('4. 정렬(제품명기준)')
    print('5. 차트보기')
    print('6. 종료')
    return input('메뉴를 선택하세요:')

while(1):
    choose = main_menu()
    d={1:pressInput, 2:pressOutput, 3:pressSearch, 4:pressSort, 5:pressChart}

    d.get(int(choose), pressExit)()

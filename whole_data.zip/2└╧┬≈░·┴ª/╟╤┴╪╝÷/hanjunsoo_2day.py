#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

mysr=pd.Series()

def menu():
    print('1. 입력')
    print('2. 출력')
    print('3. 검색')
    print('4. 정렬(제품명기준)')
    print('5. 차트보기')
    print('6. 종료')
    return input('메뉴를 선택하세요:')

def Input():
    while(1):
        p = input('제품명:')
        n = int (input('수량:'))
        mysr[p] = n
        if input('계속입력(y/n)?') == 'n':
            break

def Output():
    print("="*30)
    print("%10s%10s"%('제품명','수량'))
    print("="*30)
    for i,v in mysr.items():
          print("%10s%10d"%(i,v))

def Search():
    p = input('검색제품명입력:')
    print("="*30)
    print("%10s%10s"%('제품명','수량'))
    print("="*30)
    print(p, " "*5, mysr[p])

def Sort():
    print(mysr.sort_values(ascending=False))
    print("="*30)
    print("%10s%10s"%('제품명','수량'))
    print("="*30)
    for i,v in mysr.items():
          print("%10s%10d"%(i,v))

def Chart():
    mysr.plot(kind='bar')
    plt.show()

def Exit():
    exit(0)

while(1):
    choose = menu()
    d={1:Input, 2:Output, 3:Search, 4:Sort, 5:Chart}
    d.get(int(choose), Exit)()


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False

srdata = pd.Series();

def inputData():
    while True:
        print('1.입력')
        pname = input('제품명:')
        srdata[pname] = int(input('수량:'))
        if(input('계속입력(y/n)?') == 'n'):
            break

def printData():
    print('2. 출력')
    for pname, cnt in srdata.items():
        print(pname, cnt)


def searchData():
    print('3. 검색')
    in_name = input('검색제품명입력: ')
    for pname, cnt in srdata.items():
       if(pname == in_name):
          print(pname, cnt)

def sortData():
    print('4. 정렬(제품명기준)')
    print(srdata.sort_index())

def viewChart():
    # print('Not support')
    srdata.plot(kind='bar')
    plt.show()

menu = {1:inputData, 2:printData, 3:searchData, 4:sortData, 5:viewChart}

while True:
    print('제품수량관리','------','1. 입력','2. 출력','3. 검색','4. 정렬(제품명기준)','5. 차트보기(바차트)','6. 종료', sep='\n')
    in_num = int(input('메뉴를 선택하세요: '))
    if(in_num == 6):
        break
    else:
        menu[in_num]()

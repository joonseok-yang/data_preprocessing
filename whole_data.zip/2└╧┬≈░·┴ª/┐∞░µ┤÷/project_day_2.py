import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False

# 판다스 시리즈 데이터구조를 이용하여 
# 다음을 작성하시요.


# 제품수량관리
# -----
# 1. 입력
# 2. 출력
# 3. 검색
# 4. 정렬(제품명기준)
# 5. 차트보기
# 6. 종료
# 메뉴를 선택하세요:

# 1.입력
# 제품명:
# 수량:
# 계속입력(y/n)?

# 2.출력
# ----------------
# 	제품명		수량
# ----------------

# 3.검색
# 검색제품명입력:
# ----------------
# 	제품명		수량
# ----------------

# 4.정렬결과 출력
# 5.차트보기
# 6.종료

productSeries = pd.Series()

def printMenu():
    print("-"*30)
    print("제품수량관리")
    print("-"*30)
    print("1. 입력")
    print("2. 출력")
    print("3. 검색")
    print("4. 정렬")
    print("5. 차트")
    print("6. 종료")
    print("-"*30)
    return input("메뉴를 입력하세요 : ")

def insertProduct(name, quantity):
    productSeries[name] = quantity

def numberOne():
    while 1 :
        productName = input("제품명 : ")
        productQuantity = int(input("수량 : "))
        insertProduct(productName, productQuantity)
        isContinue = input("계속입력(y/n)?")
        if isContinue == 'n' :
            return

def numberTwo():
    print("-"*30)
    print("%10s%10s"%('제품명', '수량'))
    print("-"*30)
    for i, v in productSeries.items():
        print("%10s%10d"%(i,v))
    print("-"*30)
    
def numberThree():
    productName = input("제품명 : ")
    print("-"*30)
    print("%10s%10s"%('제품명', '수량'))
    print("-"*30)
    print("%10s%10d"%(productName, productSeries.get(productName, default=0)))
    print("-"*30)
    
def numberFour():
    print("-"*30)
    print("%10s%10s"%('제품명', '수량'))
    print("-"*30)
    for n in productSeries.index.sort_values():
        print("%10s%10d"%(n,productSeries[n]))
        
def numberFive():
    productSeries.plot(kind='bar')
    plt.show()
    
def main():
    while 1:
        menuNumber = printMenu()
        if (menuNumber == '1'):
            numberOne()
        elif (menuNumber == '2'):
            numberTwo()
        elif (menuNumber == '3'):
            numberThree()
        elif (menuNumber == '4'):
            numberFour()
        elif (menuNumber == '5'):
            numberFive()
        elif (menuNumber == '6'):
            return
        else:
            print("잘못된 번호입니다.")
        
main()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False
sr = pd.Series()

def show_series(s):
    print("\t\t\t" + "-" * 30)
    print("\t\t\t" + "\t%s\t\t%s" % ("제품명", "수량"))
    print("\t\t\t" + "-" * 30)
    for rec in s.items():
        print("\t\t\t" + "\t%s\t\t%s" % rec)
    print("\t\t\t" + "-" * 30)

def m01_input():
    global sr
    yn = "y"
    while yn == "y" or yn == "Y":
        print("\t\t\t1. 입력")
        name = input("\t\t\t - 제품명: ")
        cnt = int(input("\t\t\t - 수량: "))
        sr[name] = cnt
        yn = input("\t\t\t계속입력(y/n)? ")

def m02_show():
    global sr
    print("\t\t\t2. 출력")
    show_series(sr)

def m03_search():
    global sr
    print("\t\t\t3. 검색")
    name = input("\t\t\t검색제품명: ")
    show_series(sr[sr.index.str.contains(name)])

def m04_sort():
    global sr
    print("\t\t\t4. 정렬결과 출력")
    show_series(sr.sort_index())

def m05_chart():
    global sr
    print("\t\t\t5. 차트보기")
    sr.plot(kind='bar')
    plt.show()

def m06_exit():
    print("\t\t\t6. 종료")

def m00_invalid():
    pass

def main():
    no = 0
    menu = [m00_invalid, m01_input, m02_show, m03_search, m04_sort, m05_chart, m06_exit]
    while no != 6:
        print(
            '''
            제품수량관리
            ------------
            1. 입력
            2. 출력
            3. 검색
            4. 정렬(제품명기준)
            5. 차트보기(바차트)
            6. 종료
            메뉴를 선택하세요: '''
        )
        no = int(input().strip())
        menu[no]()


if __name__ == '__main__':
    main()

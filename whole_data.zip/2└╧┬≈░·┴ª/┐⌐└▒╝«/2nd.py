#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import sys
matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False


# In[ ]:

manager = pd.Series()

while True:
    print('제품수량 관리')
    print('-'*10)
    print('1. 입력')
    print('2. 출력')
    print('3. 검색')
    print('4. 정렬(제품명기준)')
    print('5. 차트보기(바차트)')
    print('6. 종료')
    str = input('메뉴를 선택하세요: ')
    mu = int(str)

    if mu == 6:
        sys.exit()
    elif mu == 1:
        while True:
            name = input('제품명: ')
            n = int(input('수량: '))
            manager[name] = n
            go = input('계속입력(y/n)?')
            if go == 'n':
                break;
    elif mu == 2:
        print('--------------')
        print('제품명\t수량')
        print('--------------')
        for i, v in manager.items():
            print(i, v, sep='\t')
    elif mu == 3:
        str = input('검색제품명입력: ')
        print('--------------')
        print('제품명\t수량')
        print('--------------')
        rst = manager[ manager.index.str.contains(str) ]
        for i, v in rst.items():
            print(i, v, sep='\t')
    elif mu == 4:
        rst = manager.sort_index()
        for i, v in rst.items():
            print(i, v, sep='\t')
    elif mu == 5:
        manager.plot(kind='bar')
        plt.show()

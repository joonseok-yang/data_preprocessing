import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

mysr = pd.Series()

def pr_add():
    name = input('제품명:')
    count = int(input('수량:'))
    mysr[name] = count
    return

def pr_print():
    print(mysr)
    return

def pr_search():
    name = input('제품명:')
    print(mysr[name])
    return

def pr_chart():
    mysr.plot(kind='bar')
    plt.show()
    return
a = 1

while a==1:
    print('제품수량관리')
    print('-'*5)
    print('1.입력')
    print('2.출력')
    print('3.검색')
    print('4.정렬(제푸명 기준으로)')
    print('5.차트보기(바차트)')
    print('6.종료')
    print('-'*5)
    menu = int(input('메뉴:'))
    print('-'*5)
    if menu == 1:
        pr_add()
    elif menu == 2:
        pr_print()
    elif menu == 3:
        pr_search()
    elif menu == 4:
        mysr = mysr.sort_index()
        pr_print()
    elif menu == 5:
        pr_chart()
    elif menu == 6:
        a=2
    print('-'*5)


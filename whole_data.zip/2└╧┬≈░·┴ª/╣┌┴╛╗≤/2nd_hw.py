import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

def show_guide():
    print("제품수량관리")
    print('-'*5)
    print('1.입력')
    print('2.출력')
    print('3.검색')
    print('4.정렬(제품명기준)')
    print('5.차트보기(바차트)')
    print('6.종료')

db = pd.Series()
while True:
     show_guide()
     ch=int(input('메뉴를 선택하세요:'))

     if ch==1:
            print('1.입력')
            name=input('제품명:')
            count=int(input('수량:'))
            db[name]=count
     elif ch==2:
         print('-'*10)
         print('%10s%10s'%('제품명','수량'))
         print('-'*10)
         for k,v in db.items():
             print("%10s%10d"%(k,v))
     elif ch==3:
         sername=input('검색제품명입력:')
         for k,v in db.items():
            if k==sername:
                print('-'*10)
                print('%10s%10s'%('제품명','수량'))
                print('-'*10)
                print("%10s%10d"%(k,v))
     elif ch==4:
         print(db.sort_index())
     elif ch==5:
         db.plot(kind='bar')
         plt.plot()
     elif ch==6:
         break

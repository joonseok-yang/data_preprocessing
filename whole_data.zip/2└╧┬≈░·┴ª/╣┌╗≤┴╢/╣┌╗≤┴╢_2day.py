import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

print('제품수량관리')
print('-'*20)
print('1. 입력')
print('2. 출력')
print('3. 검색')
print('4. 정렬(제품명기준)')
print('5. 차트보기(바차트)')
print('6. 종료')

n = input('메뉴를 선택하세요:')

mysr=pd.Series()

def input():
    check = 'y'
    while check != 'n':
        name = input('제품명 : ')
        count = input('수량: ')
        mysr[name] = int(count)
        check = input('계속입력(y/n)?')

def output():
    print('-'*20)
    print('%10s%10s'%('제품명','수량'))
    print('-'*20)

    for n, s in mysr.items():
        print('%10s%10d'%(n,s))

def search():
    name = input('검색제품명입력:')

    print('-'*20)
    print('%10s%10s'%('제품명','수량'))
    print('-'*20)
    print('%10s%10d'%(mysr.items().index,mysr.items().values))

def sort():
    print('정렬결과 출력')
    print(mysr.sort_index())

def show():
    print('show')
    mysr.plot(kind='bar',legend=True)
    plt.show()

def exit():
    print('exit')

def menu(item) :
    while True:
        if item == 1:
            input()
        elif item == 2:
            output()
        elif item == 3:
            search()
        elif item == 4:
            sort()
        elif item == 5:
            show()
        elif item == 6:
            exit()
            return

n = int(n)
menu(n)


# 제품수량관리
# -----
# 1. 입력
# 2. 출력
# 3. 검색
# 4. 정렬(제품명기준)
# 5. 차트보기(바차트)
# 6. 종료
# 메뉴를 선택하세요:
#
# 1.입력
# 제품명:
# 수량:
# 계속입력(y/n)?
#
# 2.출력
# ----------------
# 	제품명		수량
# ----------------
#
# 3.검색
# 검색제품명입력:
# ----------------
# 	제품명		수량
# ----------------
#
# 4.정렬결과 출력
#
# 5.종료


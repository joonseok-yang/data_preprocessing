#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False


# In[ ]:



def inputF():
    c = 'y'
    while c != 'n' :
        print('1. 입력')
        a = input('제품명:')
        b = input('수량:')
        b = int(b)
        mysr[a] = b;

        c = input('계속입력(y/n?')


def outputF():
    print('-'*30)
    print("%10s%10s"%('제품명','수량'))
    print('-'*30)
    for i, v in mysr.items():
        print("%10s%10d"%(i,v))
    print('-'*30)





def serachF():
    se = input('검색제품명입력:')
    print('-'*30)
    print("%10s%10s"%('제품명','수량'))
    print('-'*30)
    print("%10s%10d"%(se,mysr[se]))



def sortF():
    # sortsr = pd.Series()
    sortsr = mysr.sort_index()
    print('-'*30)
    print("%10s%10s"%('제품명','수량'))
    print('-'*30)
    for i, v in sortsr.items():
        print("%10s%10d"%(i,v))
    print('-'*30)



def showF():
    mysr.plot(kind='bar')
    plt.plot()


menu = {1:'입력', 2:'출력', 3:'검색', 4:'정렬(제품명기준)', 5:'차트보기(바차트)', 6:'종료'}

# print('%d.%5s'%(1,menu[1]))
sel =0
mysr = pd.Series()

while sel !=6:

    print('제품수량관리')
    print('-'*10)
    for n in menu:
        print('%d.%5s'%(n,menu[n]))
    sel = input('메뉴를 선택하세요:')
    sel = int(sel);
    if sel == 1 :
        inputF()
    elif sel ==2 :
        outputF()
    elif sel ==3 :
        serachF()
    elif sel ==4 :
        sortF()
    elif sel == 5:
        showF()


# In[ ]:


mysr.plot(kind='bar')
   plt.plot()


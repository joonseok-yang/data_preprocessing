import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

def menu():
    print('제품수량관리', end='\n')
    print('-----', end='\n')
    print('1. 입력', end='\n')
    print('2. 출력', end='\n')
    print('3. 검색', end='\n')
    print('4. 정렬(제품명기준)', end='\n')
    print('5. 차트보기(바차트)', end='\n')
    print('6. 종료', end='\n')

def product():
    print('----------------', end='\n')
    print('\t제품명\t수량', end='\n')
    print('----------------', end='\n')

def menuinput(sr):
    print('1.입력', end='\n')
    in1 = input('제품명:')
    in2 = input('수량:')
    sr[in1] = in2
    menuoutput(sr)

def menuoutput(sr):
    print('2.출력', end='\n')
    product()
    for i,v in sr.items():
        print('\t' + str(i) + '\t' + str(v))

def menusearch(sr):
    in1 = input('검색제품명입력:')
    product()
    for i,v in sr[sr.index==in1].items():
        print('\t' + str(i) + '\t' + str(v))

def menusort(sr):
    product()
    for i,v in sr.sort_values():
        print('\t' + str(i) + '\t' + str(v))

def menuchart(sr):
    sr.plot(kind='bar')
    plt.show()

#sr = pd.Series()
sr = pd.Series( [90,90,55,60,76,80,76,88,30,25],name="국어점수" )
sr.index=['홍길동','이순신','임꺽정','정난정',
         '이이','이황','정도전','김철수1','김철수2','김철수3']
menu()
in1 = input('입력:')
menuin = int(in1)
menud = {1:menuinput, 2:menuoutput, 3:menusearch, 4:menusort, 5:menuchart}
menud.get(menuin, menu)(sr)

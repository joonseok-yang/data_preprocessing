import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False


def fn_input(sr):
    print('입력')
    pName = input('제품명: ')
    pTotal = int(input('수량: '))
    sr[pName] = pTotal

def fn_print(sr):
    print("-"*30)
    print("%10s%10s"%('제품명', '수량'))
    print("-"*30)
    for i,v in sr.items():
        print("%10s%10s"%(i, v))

def fn_search(sr):
    name = input('검색제품명입력: ')
    print("-"*30)
    print("%10s%10s"%('제품명', '수량'))
    print("-"*30)
    print("%10s%10s"%(name, sr[name]) )

def fn_sort(sr):
    print("-"*30)
    print("%10s%10s"%('제품명', '수량'))
    print("-"*30)
    for i,v in sr.sort_values().items():
        print("%10s%10s"%(i, v))

def fn_showChart(sr):
    sr.plot(kind='bar')
    plt.show()

def fn_default(sr):
    return 0


pdSr = pd.Series()

d = {1:fn_input, 2:fn_print, 3:fn_search, 4:fn_sort, 5:fn_showChart}
opt = 0
while opt!=6:
    print('1. 입력')
    print('2. 출력')
    print('3. 검색')
    print('4. 정렬(제품명기준)')
    print('5. 차트보기(바차트)')
    print('6. 종료')
    opt = int(input('메뉴를 선택하세요: '))
    d.get(opt, fn_default)(pdSr)


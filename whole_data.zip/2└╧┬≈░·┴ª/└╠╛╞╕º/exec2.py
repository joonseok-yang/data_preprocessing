import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#unicode 안깨지게 필요
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False

sr = pd.Series()

def inputFunc() :
    fn1 = 'y'
    val1 = []
    val2 = []
    while fn1=='y' :
        val1.append(input("제품명:"))
        val2.append(int(input("수량:")))
        fn1 = input("계속입력(y/n)?")
    sr.index = val1
    sr.append["수량"] = val2

def outputFunc() :
    print("="*30)
    print("%10s%10s"%('제품명','수량'))
    print("="*30)
    for i,v in sr.items() :
        print("%10s%10s"%(i,v))
def searchFunc() :
    na = input("제품명을 입력해주세요")
    fil = sr[sr.index.str.contains(na)]
    print("="*30)
    print("%10s%10s" %('제품명','수량'))
    print("="*30)
    for i,v in fil.items() :
        print("%10s%10s"%(i,v))

def showchartFunc() :
    #sr.plot(kind='bar')
    #plt.plot()
    print("sdf")

def endFunc() :
    return


print("1.입력")
print("2.출력")
print("3.검색")
print("4.정렬")
print("5.차트보기")
print("6.종료")
ans = input("메뉴를 선택하세요 :")

d = { '1':inputFunc, '2':outputFunc, '3':searchFunc, '4':showchartFunc, '5':endFunc }
d[ans]()

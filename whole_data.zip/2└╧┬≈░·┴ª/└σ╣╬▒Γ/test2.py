import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

def fn1(sr):
    inputFlag = 'y'
    while inputFlag == 'y':
        print('1.입력')
        name = input('제품명:')
        cnt = input('수량:')
        sr[name]=cnt
        print(sr.items())
        inputFlag = input("계속입력(y/n):")


def fn2(sr):
    print("출력")
    print('-'*30)
    print("%10s%10s"%('제품명', '수량'))
    print('-'*30)
    for i,v in sr.items():
        print("%10s%10d"%(i,v))

def fn3(sr):
    print("검색")
    name = input("검색제품명입력: ")
    print('-'*30)
    print("%10s%10s"%('제품명', '수량'))
    print('-'*30)
    print(sr[sr.index.str.contains(name)])

def fn4(sr):
    print('정렬결과 출력')
    sr.sort_index()
    print(sr)

def fn5(sr):
    print("바차트 보기")
    # sr.plot(kind=='bar')
    pd.show()

mysr = pd.Series({'aa':4})
num = 0
while num != 6:
    print('제품수량관리')
    print('----')
    print('1. 입력')
    print('2. 출력')
    print('3. 검색')
    print('4. 정렬(제품명기준)')
    print('5. 차트보기(바차트)')
    print('6. 종료')
    menu = input('메뉴를 선택하세요:')
    num = int(menu)

    mysr['cc'] = 6
    print(mysr.items())

    if num == 1:
        fn1(mysr)

    elif num == 2:
        fn2(mysr)

    elif num == 3:
        fn3(mysr)

    elif num == 4:
        fn4(mysr)

    elif num == 5:
        fn5(mysr)

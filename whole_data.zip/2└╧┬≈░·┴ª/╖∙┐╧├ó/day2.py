import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False

data = pd.Series()


def show_menu():
    print("제품수량관리")
    print("-"*20)
    print("1. 입력")
    print("2. 출력")
    print("3. 검색")
    print("4. 정렬(제품명기준)")
    print("5. 차트보기(바차트)")
    print("6. 종료")
    cmd = input("메뉴를 선택하세요:")
    return int(cmd)


def insert():
    while True:
        name = input("제품명:")
        amount = int(input("수량:"))
        data[name] = amount

        while True:
            cont = input("계속입력(y/n)?").lower()
            if cont == 'n':
                return
            elif cont == 'y':
                break


def show_list(lst):
    print("-"*20)
    print("%10s%10s" %("제품명", "수량"))
    print("-"*20)
    for i, v in lst:
        print("%10s%10d" % (i, v))


def search():
    name = input("검색제품명입력:")
    if name in data.keys():
        show_list(((name, data[name]),))
    else:
        print(">> 검색결과없음")


def show_all():
    show_list(data.items())


def show_sorted():
    sorted_data = data.sort_index()
    show_list(sorted_data.items())


def show_chart():
    data.plot(kind='bar')
    plt.show()


while True:
    cmd = show_menu()
    if cmd == 1:
        insert()
    elif cmd == 2:
        show_all()
    elif cmd == 3:
        search()
    elif cmd == 4:
        show_sorted()
    elif cmd == 5:
        show_chart()
    elif cmd == 6:
        break

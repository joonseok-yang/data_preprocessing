#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False


# In[ ]:


## 1.입력
# 제품명:
# 수량:
# 계속입력(y/n)?
kSr = pd.Series()

def sr_input():    
    cond = True
    while cond == True:
        name = input('제품명:')
        count = int(input('수량:'))
        kSr[name] = count
        cond = input('계속입력(y/n):') == 'y'
#     sr_output()

def sr_output():    
    print("="*30)
    print("%10s%10s"%('제품명','수량'))
    print("="*30)
    for i,v in kSr.items():
          print("%10s%10d"%(i,v))

def sr_search():
    prod_name = input('검색제품명입력:')    
    print('검색결과:',kSr[prod_name])
    print("="*30)
    print("%10s%10s"%('제품명','수량'))
    print("="*30)   
#     print("%10s%10d"%(kSr[prod_name], kSr[prod_name])) 

def sr_sort():
    print('정렬')

def sr_show():
    print('차트보기')

def sr_end():
    print('종료')

def show_menu():
    print('1. 입력:')
    print('2. 출력:')
    print('3. 검색:')
    print('4. 정렬(제품명기준):')
    print('5. 차트보기(바차트):')
    print('6. 종료')

menu = {1:sr_input, 2:sr_output, 3:sr_search, 4:sr_sort, 5:sr_show, 6:sr_end}
show_menu()
sel = int(input('메뉴를선택하세요:'))
while sel != 6:
    menu.get(sel,'잘못입력')()


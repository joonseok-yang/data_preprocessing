#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import warnings
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')


# In[9]:


car2014=pd.read_csv('2014년 졸음운전 교통사고.csv',engine='python')
car2014


# In[10]:


car2015=pd.read_csv('2015년 졸음운전 교통사고.csv',engine='python')
car2015


# In[11]:


car2016=pd.read_csv('2016년 졸음운전 교통사고.csv',engine='python')
car2016


# In[43]:


#1. 년도, 월별로 멀티인덱스를 설정하고 데이터를 보여 주시요
carAll = pd.concat([car2014,car2015,car2016])
carAll


# In[44]:


year=[]
month=[]
for y,m in carAll['구분'].str.split('년'):
    year.append(y + '년')
    month.append(m)

carAll['년도'] = year
carAll['월'] = month

carAll.set_index(['년도','월'],inplace=True)
carAll.drop(columns=['구분'],inplace=True)
carAll


# In[54]:


#2. 2016년 사고대비 사망율을 보여 주시요
carAll['사망율'] = carAll['사망(명)']/carAll['사고(건)'] *100
carAll.loc['2016년']


# In[57]:


#3. 2014년도 월별 사망, 부상 데이터를 바차트로 보여주시요
carAll.loc['2014년'][['사망(명)','부상(명)']].plot(kind='bar')
plt.show()


# In[72]:


#4. 2015년 대비  사망이 가장 많이 증가한 2016년도 월을 구하시요
data = carAll.loc['2016년']['사망(명)']/carAll.loc['2015년']['사망(명)']*100
data.sort_values(ascending=False).head(1)


# In[ ]:





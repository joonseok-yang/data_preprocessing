from bs4 import BeautifulSoup
import urllib.request as REQ #http통신하는 모듈
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import warnings
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')
import folium
import urllib
import json

#1 년도 월별로 멀티인덱스를 설정하고 데이터를 보여주세요
df14 = pd.read_csv('2014년 졸음운전 교통사고.csv', engine='python', thousands=',')
df15 = pd.read_csv('2015년 졸음운전 교통사고.csv', engine='python', thousands=',')
df16 = pd.read_csv('2016년 졸음운전 교통사고.csv', engine='python', thousands=',')
cf = pd.concat([df14,df15,df16])
cf.head()
cf['년도'] = cf['구분'].str.slice(0,5)
cf['월'] = cf['구분'].str.slice(5,8)
df = cf.pivot_table(index=['년도','월'])
df

#2. 2016년 사고대비 사망율을 보여주세요
df_2016 = df.loc['2016년']
df_2016['사망율'] = (df_2016['사망(명)']  / df_2016['사고(건)']) * 100
df_2016

#3. 2014년도 월별 사망 부상 데이터를 바차트로 보여주시오
df_2014 = df.loc['2014년']
df_2014.drop(columns=['사고(건)'],inplace=True)
df_2014.plot(kind='bar')
plt.show()

#4. 2015년 대비 사망이 가장 많이 증가한 2016년 도 월을 구하시오
dead = df.loc['2016년']['사망(명)']/df.loc['2015년']['사망(명)']
dead[dead.max()==dead]

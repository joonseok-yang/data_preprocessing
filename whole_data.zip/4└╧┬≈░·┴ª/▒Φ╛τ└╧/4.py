#!/usr/bin/env python
# coding: utf-8

# In[36]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import warnings

matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')


# In[21]:


df2014 = pd.read_csv(r'd:\2014년 졸음운전 교통사고.csv', engine='python')
df2015 = pd.read_csv(r'd:\2015년 졸음운전 교통사고.csv', engine='python')
df2016 = pd.read_csv(r'd:\2016년 졸음운전 교통사고.csv', engine='python')
df = pd.concat([df2014, df2015, df2016])
year = []
month =[]
for y, m in df['구분'].str.split('년'):
    year.append(y)
    month.append(m)
df['년'] = year
df['월'] = month
df.set_index(['년', '월'])


# In[35]:


# 2016년 사고대비 사망율을 보여 주시요
d2016 = df[ df['년'] == '2016']
d2016['사망(명)'].sum() / d2016['사고(건)'].sum() * 100
    
# for d in df[ df['년'] == '2016']:
#     print(d)


# In[54]:


d2014 = df[ df['년'] == '2014']
d2014[['사망(명)','부상(명)']].plot(kind='bar')


# In[64]:



d = d2016['사망(명)'] / d2015['사망(명)']
d2016['증가율'] = d
d2016[d2016['증가율'].max() == d2016['증가율']]


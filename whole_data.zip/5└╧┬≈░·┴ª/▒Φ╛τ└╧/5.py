#!/usr/bin/env python
# coding: utf-8

# In[18]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import warnings
import seaborn as sns
from scipy import stats
import statsmodels.api as sm


matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['font.size']=15
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')


# In[3]:


df = pd.read_csv(r'd:\cars.csv', index_col = 'Unnamed: 0')
df


# In[4]:


df.corr()


# In[8]:


plt.scatter(df.speed, df.dist)
plt.show()


# In[11]:


# 귀무가설 : 속도와 거리간에 연관성이 없다
# 대립가설 : 있다

result = stats.linregress (df.speed, df.dist)
result
print('기울기', result.slope)
print('절편', result.intercept)
print('상관계수', result.rvalue)
print('p-value', result.pvalue)
print('편차', result.stderr)

# 0.1(귀무10, 대립채택90)
# 0.05(귀무5, 대립채택95)
# 0.01(귀무1, 대립채택99)


# In[12]:


df['lm'] = df['speed'] * result.slope + result.intercept
# y =  x * result.slope + result.intercept
df


# In[13]:


plt.scatter(df.speed, df.dist)
plt.plot(df.speed, df['lm'])
plt.show()


# In[17]:


sns.lmplot(x='speed', y='dist', data=df)
plt.show()


# In[19]:


# model = sm.OLS.from_formula(dist~speed+oil', df))
model = sm.OLS.from_formula('dist~speed', df)
result = model.fit() # training
result.summary()


# In[20]:


result.params


# In[21]:


titanic = sns.load_dataset('titanic')
titanic


# In[24]:


titanic.drop(columns = ['deck'], inplace=True)


# In[37]:


titanic


# In[41]:


titanic.dropna(subset=['age'], inplace=True)
titanic


# In[107]:


print('생존자', titanic [ titanic['survived'] == 1 ]['survived'].count())


# In[108]:


print('사망자', titanic [ titanic['survived'] == 0]['survived'].count())


# In[76]:


def fns(v):
    return titanic [ (titanic['pclass'] == v) & titanic['survived'] == 1]['survived'].count() / titanic ['survived'].count() * 100


# In[79]:


print('1st : ',  fns(1))
print('2nd : ',  fns(2))
print('3rd : ',  fns(3))


# In[91]:


print('가족 : ', titanic [( titanic['survived'] == 1) & (titanic['sibsp'] != 0) ]['survived'].count() /  titanic['survived'].count() * 100)


# In[92]:


print('혼자 : ', titanic [( titanic['survived'] == 1) & (titanic['alone'] == 1) ]['survived'].count() /  titanic['survived'].count() * 100)


# In[110]:


dfare = pd.DataFrame({1: [titanic [ titanic['pclass'] == 1]['fare'].mean()], 
                      2: [titanic [ titanic['pclass'] == 2]['fare'].mean()], 
                      3: [titanic [ titanic['pclass'] == 3]['fare'].mean()]})
# dfare
dfare.plot(kind='bar')
plt.show()

# >>> df = pd.DataFrame({"name": ['Alfred', 'Batman', 'Catwoman'],
# ...                    "toy": [np.nan, 'Batmobile', 'Bullwhip'],
# ...                    "born": [pd.NaT, pd.Timestamp("1940-04-25"),
# ...                             pd.NaT]})


# In[135]:


print('남자 : ', titanic [( titanic['survived'] == 1) & (titanic['sex'] == 'male') ]['survived'].count() /  titanic['survived'].count() * 100)
print('여자 : ', titanic [( titanic['survived'] == 1) & (titanic['sex'] == 'female') ]['survived'].count() /  titanic['survived'].count() * 100)


# In[115]:


bun = []
def fnBun(v):
    if 1 <= v <= 15:
        return '미성년자'
    elif 15 < v <= 25:
        return '청년'
    elif 25 < v <= 35:
        return '중년'
    elif 35 < v <= 60:
        return '장년'
    else:
        return '노년'

for n in titanic['age']:
    bun.append(fnBun(int(n)))
titanic['나이분류'] = bun


# In[116]:


titanic


# In[137]:


plt.figure(figsize = [5,5])
plt.pie(titanic.groupby(by='나이분류')['나이분류'].count(), autopct='%1.f%%', shadow=True)
plt.show()


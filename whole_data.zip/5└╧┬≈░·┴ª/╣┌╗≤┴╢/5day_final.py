#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
import statsmodels.api as sm
import warnings
# from datetime import datetime, time, date
# from pandas_datareader import data
from scipy import stats

matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['font.size']=15
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')


# In[102]:


titanic = sns.load_dataset('titanic')
titanic


# In[103]:


#1.deck 컴럼을 삭제하고 나이(age)의 nan 데이터를 삭제 하시요
titanic.drop(columns=['deck'],inplace=True)
titanic


# In[104]:


#1.deck 컴럼을 삭제하고 나이(age)의 nan 데이터를 삭제 하시요
titanic.dropna(subset=['age'],inplace=True)
titanic


# In[105]:


#2.생존자와 사망자에 대한 갯수를 구하시요
live_count = titanic[titanic['survived']==1]['survived'].count()
print('생존자수: ', live_count)


# In[106]:


#2.생존자와 사망자에 대한 갯수를 구하시요
dead_count = titanic[titanic['survived']==0]['survived'].count()
print('사망자수: ', dead_count)


# In[107]:


#3.등급별(pclass) 평균 생존률을 구하시요
# first = titanic[(titanic['pclass'] == 1) & (titanic['survived']==1)].count()/titanic[titanic['survived']==1].count()*100
first = titanic[(titanic['pclass'] == 1) & (titanic['survived']==1)].count()/titanic[titanic['survived']==1].count()*100
second = titanic[(titanic['pclass'] == 2) & (titanic['survived']==1)].count()/titanic[titanic['survived']==1].count()*100
third = titanic[(titanic['pclass'] == 3) & (titanic['survived']==1)].count()/titanic[titanic['survived']==1].count()*100
print('1st class 평균 생존률:', round(first['pclass'],2),'%')
print('2nd class 평균 생존률:', round(second['pclass'],2),'%')
print('3rd class 평균 생존률:', round(third['pclass'],2),'%')


# In[108]:


#4. SibSp(가족과탑승) 의 평균 생존율을 구하시요
live = titanic[(titanic['survived'] == 1) & (titanic['sibsp']!=0)].count()/titanic['sibsp'].count()*100
print('가족과 탑승의 평균 생존율:', round(live['sibsp'],2),'%')


# In[109]:


#5.등급별 티켓비용(fare) 의 평균 차트로 그리시요
grade = []

fm_fare = titanic[titanic['pclass'] == 1]['fare'].mean()
sm_fare = titanic[titanic['pclass'] == 2]['fare'].mean()
tm_fare = titanic[titanic['pclass'] == 3]['fare'].mean()

grade.append(fm_fare)
grade.append(sm_fare)
grade.append(tm_fare)

df=pd.DataFrame(grade)
df.index = ['first','second','third']
df.plot(kind='bar')

plt.show()


# In[114]:


#6.성별 평균 생존율을 구하시요 
male = titanic[(titanic['sex'] == 'male') & (titanic['survived']==1)].count()/titanic['survived'].count()*100
female = titanic[(titanic['sex'] == 'female') & (titanic['survived']==1)].count()/titanic['survived'].count()*100
print('남성 생존율: ',round(male['sex'],2))
print('여성 생존율: ',round(female['sex'],2))


# In[115]:


#7. 혼자탑승(alone)한 인원의 평균 생존율을 구하시요
live = titanic[(titanic['survived'] == 1) & (titanic['sibsp']==0)].count()/titanic['sibsp'].count()*100
print('혼자 탑승한 사람 평균 생존율:', round(live['sibsp'],2),'%')


# In[ ]:





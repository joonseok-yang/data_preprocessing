def calcbmi( h, w):
    stdWeight=(h-100)*0.85
    bmi=w/stdWeight*100
    if bmi<=90:
        return '저체중'
    elif 90< bmi<=110:
        return '정상'
    elif 110< bmi<=120:
        return '과체중'
    else:
        return '비만'

def yunYear( year):
    return "윤년" if year%4==0 and year%100!=0 or year%400==0 else "윤년아님"

def nai(year):
    return 2019-year+1

def ttee(year):
    return ('원숭이','닭','개','돼지','소','범','토끼','용','뱀','말','양')[year%12]

def grade( jumsu):
    # d = {10:'A',9:'A',8:'B',7:'C',6:'D'}
    return  {10:'A',9:'A',8:'B',7:'C',6:'D'}.get(jumsu//10,'F') #d[jumsu//10]

def mToMile( meter):
    return meter*0.000621

def fToC( f):
    return (f-32)/1.8

def yaksu( num):
    return [n for n in range(1,num+1) if num%n==0]

def myabs( n1, n2):
    n1 = -1*n1 if n1<0 else n1
    n2 = -n2 if n2<0 else n2
    return n1+n2

def mymap( key, dt):
    return [ key(n) for n in dt ]

print( mymap(lambda v:v+2,[1,2,3,4]) )


# data =[1,2,3,4]
# m = map( lambda v:v+2,data)
# print( list(m) )




























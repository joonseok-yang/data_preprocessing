import time

'''
1. 키와 몸무게를 입력받아 비만도를 구하고 결과를 출력하시요(함수를 만드시요)
표준체중(kg)=(신장(cm)-100)×0.85
비만도(%)=현재체중/표준체중(%)×100

비만도가90%이하
저체중,
90초과~110%
정상,
110초과~120%
과체중,
120%초과
비만
'''

def obDecision(ob):
    if ob<=90:
        print('저체중:', ob)
    elif ob<=110:
        print('정상:', ob)
    elif ob<=120:
        print('과체중:', ob)
    else:
        print('비만:', ob)

height = int(input('키 입력:'))
weight = int(input('몸무게 입력:'))

obesity = float((height-100))*0.85
obratio = weight/obesity*100
obDecision(obratio)

'''
2. 년도 입력받아
1) 윤년여부를 출력하시요
윤년의 조건
1-1) 4로 나눠 떨어지지만 100으로 나눠 떨어지지 않아야 한다 또는
1-2) 400 으로 나눠 떨어지면 윤년임
2) 나이를 출력하시요
3) 띠(12지신)를 출력하시요
'''

ddee = {'1': '쥐띠', '2': '소띠','3': '범띠', '4':'토끼띠','5':'용띠', '6':'뱀띠',
        '7':'말띠', '8':'양띠','9':'원숭이띠', '10':'닭띠','11':'개띠', '0':'돼지띠'}

in_year = int(input('년도 입력:'))
isLunar = False
if (in_year%4 == 0 and in_year%100 != 0) or in_year%400:
    isLunar = True
age = int(time.strftime("%Y"))-in_year

print('1. 윤년: ', isLunar)
print('2. 나이:', age)
print('3.  띠:', ddee[str(age%12)])

grade = {'10':'A','9':'A', '8':'B', '7':'C', '6':'D', '5':'F','4':'F','3':'F','2':'F','1':'F','0':'F'}
point = int(input('점수 입력:'))
print(grade[str(int(point/10))])

# 4. m 를 입력받아 마일로 변환하시요(함수를 만드시요)

def meterTomiles(m):
    return m*0.000621371

meter = float(input('미터를 입력하시오(마일로 변환):'))
print(meterTomiles(meter))

# 5. 화씨 를 입력받아 도로 변환하시요(함수를 만드시요)
def cToF(c):
    return ((c - 32) * 5/9)

celcius = float(input('화씨를 입력하시오(도로 변환):'))
print(cToF(celcius))

# 6. 하나의 정수를 입력받아 약수를 구하는 함수를 만드시요.
def getfactors(n):
    factors = []
    m = n / 2
    for m in range (1, int(n/2)):
        if n % m == 0:
            factors.append(m)
            factors.append(int(n/m))

    return factors

integer = int(input('정수를 입력하시오 (약수 구하기):'))
print(getfactors(integer))

# 8. map 함수와 동일한 기능을 하는 mymap 함수를 구현하시요.

data = [1, 2, 3, 4, 5]

def fn(v):
    return v*10

def mymap(dt, key):
    return [n for n in dt if key(n)]

rst = mymap(data, fn)
print(rst)


def bmi(h, w):
    stdWeight = (h-100)*0.85
    return w/stdWeight*100

height = int(input('height= '))
weight = int(input('weight= '))
#print(bmi(height, weight))
rst = bmi(height, weight)

if rst > 120:
    print('비만')
elif 120 >= rst > 110:
    print('과체중')
elif 110 >= rst > 90:
    print('정상')
else:
    print('저체중')

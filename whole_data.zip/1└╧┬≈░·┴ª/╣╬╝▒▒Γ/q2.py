import datetime

def leapYear(y):
    return True if (year%4==0 and year%100!=0) or year%400==0 else False

def ageFromYear(y):
    dt = datetime.datetime.now()
    return dt.year - y

def ddiFromAge(a):
    ddi = '신유술해자축인묘진사오미'
    return ddi[a%12]

year = int(input("year= "))

print(leapYear(year))
rst1 = ageFromYear(year)
print("age: ", rst1)
print("ddi: ", ddiFromAge(rst1))




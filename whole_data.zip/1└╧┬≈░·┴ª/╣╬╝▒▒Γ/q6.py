
def calcYak(i):
    for n in range(1,i):
        if i % n == 0:
            print(n)


iV = int(input("integer= "))
calcYak(iV)

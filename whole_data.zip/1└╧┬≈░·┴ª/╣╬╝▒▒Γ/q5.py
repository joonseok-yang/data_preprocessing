
def fToC(f):
    return (f - 32) * 5/9


fah = float(input("fahrenheit= "))
print(fToC(fah))

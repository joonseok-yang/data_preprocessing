
def mile(m):
    return m / 1609.344


mitter = int(input("mitter= "))
print(mile(mitter))

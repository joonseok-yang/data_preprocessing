
def fnA():
    print('A')

def fnB():
    print('B')

def fnC():
    print('C')

def fnD():
    print('D')

def fnF():
    print('F')


score = int(input("Score= "))
score //= 10

d = {9:fnA, 8:fnB, 7:fnC, 6:fnD}
d.get(score, fnF)()

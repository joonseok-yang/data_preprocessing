# 1
# def check_biman(b):
#     if b > 120 :
#         print('비만')
#     elif 110 < b <=120:
#         print('과체중')
#     elif 90 < b <=110:
#         print('정상')
#     else:
#         print('저체중')
#
#
# def fn1_input(cm, kg):
#     check_biman(int(kg/(cm-100)*0.85*100))
#
# cm = input('키:')
# kg = input('몸무게:')
# fn1_input(int(cm),int(kg))

####################################
# 2

# def check_animal(y):
#     n = y%12
#     if n == 0:
#         print('쥐')
#     elif n == 1:
#         print("소")
#     elif n == 2:
#         print("호랑이")
#     elif n == 3:
#         print("토끼")
#     elif n == 4:
#         print("용")
#     elif n == 5:
#         print("뱀")
#     elif n == 6:
#         print("말")
#     elif n == 7:
#         print("??")
#     elif n == 8:
#         print("원숭이")
#     elif n == 9:
#         print("닭")
#     elif n == 10:
#         print("강아지")
#     elif n == 11:
#         print("돼지")
#
# def check_age(y):
#     print('나이:' + str(y))
#
# def check_year(y):
#     if (y%4==0 and y%100 !=0) or  y%400 == 0:
#         print('윤년 O')
#     else:
#         print('윤년 X')
#
# year = input('년도 입력:')
#
# check_year(int(year))
# check_age(int(year))
# check_animal(int(year))

#########################################################

# 3

n = input('점수:')

a=int(n)

d={'A':90<=a<=100, 'B':80<=a<=89, 'C':70<=a<=79, 'D':60<=a<69, 'F':60>a}

def myfilter(dt):
    return [n for n in dt if n == True]

ret = myfilter(d)
print(ret)

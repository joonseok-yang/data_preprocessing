def isleap(y):
    if (y%4 == 0 and y%100 != 0) or (y%400 == 0):
        print(y,'년도는 윤년입니다')
    else:
        print(y,'년도는 윤년이 아닙니다')

year = int(input('년도:'))

isleap(year)



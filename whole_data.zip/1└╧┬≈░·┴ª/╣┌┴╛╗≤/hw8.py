def mymap(fn,data):
    return [fn(v) for v in data]

data=[10,20,30,40,50]
m = mymap(lambda v:v+2, data)
print(m)

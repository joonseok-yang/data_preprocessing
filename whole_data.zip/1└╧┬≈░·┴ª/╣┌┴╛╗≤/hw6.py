def divisor(n):
    return [v for v in range(1,n+1) if n%v == 0]

number = int(input('정수:'))

print(divisor(number))

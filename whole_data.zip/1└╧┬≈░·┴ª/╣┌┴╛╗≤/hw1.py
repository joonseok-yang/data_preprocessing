def cal_obesityrate(h,w):
    return w/((h-100)*0.85)*100

height = int(input('키:'))
weight = int(input('몸무게:'))

obesityrate = cal_obesityrate(height,weight)

if obesityrate > 120:
    print('비만')
elif 110 < obesityrate <= 120:
    print('과체중')
elif 90 < obesityrate <= 110:
    print('정상')
else:
    print('저체중')

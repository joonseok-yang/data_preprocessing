def fahrenTocelsius(f):
    return (f-32)*5/9

fahren = int(input('Fahrenheit:'))

celsius = fahrenTocelsius(fahren)
s = f'{fahren}Fahrenheit 는 {celsius}도 이다'
print(s)

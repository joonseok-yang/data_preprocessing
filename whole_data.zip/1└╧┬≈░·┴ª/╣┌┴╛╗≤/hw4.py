def kmTomile(k):
    return k/1.609344

km = int(input('km:'))
mile = kmTomile(km)
s = f'{km}km 는 {mile}mile 이다'
print(s)

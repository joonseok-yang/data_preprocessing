def abtsum(a,b):
    if a<0 and b<0:
        return -a-b
    elif a<0 and b>=0:
        return -a+b
    elif a>=0 and b<0:
        return a-b
    else:
        return a+b


number1 = int(input('정수1:'))
number2 = int(input('정수2:'))

print(abtsum(number1,number2))

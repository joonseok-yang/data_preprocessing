# 1
h = input('input the height: ')
height = int(h)
w = input ('input the weight: ')
weight = int(w)

def result(height, weight):
    std_w = (height-100)*0.85
    rst = weight/std_w*100
    return rst

result = result(height, weight)
print(result)

if result <= 90:
    print('저체중')
elif 90 < result <= 110:
    print('정상')
elif 110 < result <= 120:
    print('과체중')
elif 120 < result:
    print('비만')

# 2
str = input('input the year: ')
year = int(str)

if ((year%4 == 0) and not(year%100 != 0)) or (year%400 == 0):
    print('윤년입니다.')
else:
    print('윤년이 아닙니다.')
print('나이는', 2019-year + 1, '입니다.')
data = ['자', "축", '인', '묘', '진', '사', '오', '미', '신', '유', '술', '해']

print('띠는', data[year%12 - 4], '입니다')

# 3
str = input('input the score:')
score = int(str)

std = { 'A':lambda v:90<=v<=100, 'B':lambda v:80<=v<=89, 'C':lambda v:70<=v<=79, 'D':lambda v:60<=v<=69, 'F':lambda v:v<60}

for key, value in std.items():
    if value(score):
        print(key)

# 4
str = input('input the meter: ')
m = int(str)

def mTomile(meter):
    return meter*0.000621371

print('miles are', mTomile(m))

# 5
str = input('input the 화씨: ')
f = int(str)

def fTCel(faren):
    return (faren-32)*1.8

print('섭씨 is', fTCel(f))

str = input('input the digit: ')
d = int(str)
rst = []
i = 1;
while i <= d:
    if (d % i == 0):
        rst.append(i)
    i = i + 1

print(rst)

# 7
str1 = input('inpt the integer: ')
d1 = int(str1)

str2 = input('inpt the integer: ')
d2 = int(str2)

def myabs(n):
    if n < 0:
        return n * -1
    else:
        return n

print(myabs(d1) + myabs(d2))

# 8

def mymap(fn, data):
    return [fn(n) for n in data]

print( mymap(lambda v:v+2, [1, 2]) )


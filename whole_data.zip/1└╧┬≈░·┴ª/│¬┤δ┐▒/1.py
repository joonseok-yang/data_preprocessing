def bi(a,b):
    pc = (a-100)*0.85
    return b/pc*100


# print(bi(182,80))
def defineB():
    a = input('키:');
    b = input('몸무게:')
    a = int(a)
    b = int(b)

    av = bi(a,b)

    if av <= 90:
        print('저체중')
    elif 90 < av <= 110:
        print('정상')
    elif 110 < av <= 120:
        print('과체중')
    else :
        print('비만')


def yun(a):
    rst = False
    if a%4 == 0 and a%100 !=0:
        rst = True
    
    if a%400 == 0:
        rst = True
    
    return rst
    

def defindYear() :
    a = input('년도:')
    a= int(a)
    
    if(yun(a)):
        print('윤년')
    else:
        print('윤년아님')
    
    print(2019-a,end='세')
    print()
    a =a +8;
    ji = a%12
    d = ['쥐','소','호랑이','토끼','용','뱀','말','양','원숭이','닭','개','돼지']
    
    print(d[ji], end='띠')

def dicG():
    # a = input('점수:')
    d = {'A':[90,100], 'B':[80,89],'C':[70,79],'D':[60,69]}
    print(d.values())
    print(d.get('a', 0))


def mTomile():
    a = input('M 입력:')
    a = int(a)
    print(a*0.000621371,end='')
    print('마일')

def FtoC():
    a = input('F:')
    a = int(a)
    a = (a-32) * (5/9)
    print(a)

def yak() :
    a = input('약수:')
    a = int(a)
    for i in range(1, 1+a):
        if(a%i == 0):
            print(i)

def jhap() :
    a = input('1:')
    b = input('2:')
    a=int(a)
    b = int(b)
    if(a<0):
        a*=-1
    if(b<0):
        b*=-1
    print(a+b)


def mymap(fn, data) :

    for n in data:
        print(fn(n))
    # return temp





defineB()
defindYear()
# dicG()
mTomile()
FtoC()
yak()
jhap()

data = [1,2,3]
# lambda v:v+2,data)
# print(mymap(lambda v:v+2,data))
mymap(lambda v:v+2,data)

def bmi(w,h):

    pyojun = (h-100)*0.85
    biman = w/pyojun*100

    if biman <= 90:
        print('저체중')
    elif 90 < biman <= 110:
        print('정상')
    elif 110 < biman <= 120:
        print('과체중')
    else :
        print('비만')
# bmi(170, 60 )

def yunYear(year):
    if ((year/4 == 0 and year%100 != 0) or (year%400 ==0 )):
        return '윤년'
    else:
        return '윤년아님'
# print(yunYear(2019))

def nai(year):
    return 2019-year+1
# print(nai(1982))

def ddi(year):
    data = ['자', '축', '인', '묘', '진','사', '오', '미', '신', '유', '술', '해']
    year = year-4
    return data[year%12]
# print(ddi(1980))

def gradefn( jumsu):
    d = {100:'A',90:'A',80:'B',70:'C',60:'D'}
    return  d.get(jumsu,'F')
# print(gradefn(90))

def meterTomile(meter):
    return meter*0.000621
print(meterTomile(30))

def fToC(f):
    return (f-32)/1.8
# print(fToC(48))

def yaksu( num):
    return [ n for n in range(1,num+1) if num%n==0]
# print(yaksu(6))

def myabs( a, b):
    a = -1*a if a<0 else a
    b = -b if b<0 else b
    return a+b

def mymap( fn, data):
    return [ fn(n) for n in data ]


def No1():
    h = int(input("키:"))
    w = int(input("몸무게:"))
    sw = (h - 100) * 0.85
    bmi = w / sw * 100
    if bmi <= 90:
        print("저체중")
    elif bmi <= 110:
        print("정상")
    elif bmi <= 120:
        print("과체중")
    else:
        print("비만")

def No2():
    y = int(input("년도:"))
    print("윤년" if (y % 4 == 0 and not y % 100 == 0) or y % 400 == 0 else "윤년아님")
    print("나이:", 2019 - y + 1)
    d={0:'쥐',1:'소',2:'호랑이',3:'토끼',4:'용',5:'뱀',6:'말',7:'양',8:'원숭이',9:'닭',10:'개',11:'돼지'}
    print("띠:", d[(y + 8) % 12])

def No3():
    s = int(input("점수:"))
    d={'A':(90,100),'B':(80, 89),'C':(70, 79),'D':(60, 69),'F':(0, 59)}
    for k, v in d.items():
        if v[0] <= s <= v[1]:
            return k

def No4():
    return int(input("미터:")) * 0.000621

def No5():
    return (int(input("화씨온도:")) - 32) / 1.8

def No6():
    n = int(input("정수:"))
    d =[]
    for i in range(1, n+1):
        if n % i == 0:
            d.append(i)
    return d

def No7():
    a = int(input("첫번째:"))
    b = int(input("두번째:"))
    return (a if a >=0 else -a) + (b if b >=0 else -b)

def mymap(func, iter):
    r = []
    for i in iter:
        r.append(func(i))
    return r


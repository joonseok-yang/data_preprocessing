def ex1() :
    a = input('hi(cm) : ')
    b = input('kg : ')
    a = int(a)
    b = int(b)
    kg = (a-100)*0.85
    he = b/kg*100

    if he <= 90 :
        print('저체중')
    elif 90 < he <= 110 :
        print('정상')
    elif 110 < he <= 120 :
        print('과체중')
    elif 120 < he  :
        print('비만')

def ex2() :
    year = input('year :')
    year = int(year)
    if ((year%4)==0 and (year%100)!=0) or (year%400==0) :
        print('윤년')

    print("나이", 2019-year)

def myfilter(dt, key) :
    return key(dt)

def defaultFn() :
    print('E')


def ex3() :
    score = input("score :")
    score = int(score)
    rst = -1

    fn = myfilter(score, lambda v:90<=v<100)
    fn2 = myfilter(score, lambda v:90<=v<100)
    fn3 = myfilter(score, lambda v:90<=v<100)
    fn4 = myfilter(score, lambda v:90<=v<100)

    if 90<= score < 100 :
        rst = 1
    elif 80<= score < 89 :
        rst = 2
    elif 70<= score < 79 :
        rst = 3
    elif 60<= score < 69 :
        rst = 4


    d={1:fn, 2:fn2, 3:fn3, 4:fn4}
    d.get(rst,defalutFn)()

def toMile(m) :
    return m * 0.000621371

def ex4() :
    m = input('m :')
    m = int(m)
    m = toMile(m)
    print(m)

def toDegree(m) :
    return m-32

def ex5() :
    m = input("F : ")
    m = int(m)
    m = toDegree(m)
    print(m)

def ex6() :
    en = input('enter number :')
    en = int(en)
    rst=[]
    for i in range(1,en) :
        if (en%i)==0 :
            rst.append(i)
    print(rst)

def ex7() :
    num1 = input('number1 :')
    num2 = input('number2 :')
    num1 = int(num1)
    num2 = int(num2)
    num1 = abs(num1)
    num2 = abs(num2)
    print(num1+num2)

def ex8(dt,key) :
    return [key(n) for n in dt]

ex1()
ex2()
ex3()
ex4()
ex5()
ex6()
ex7()
my = ['10', '20', '30']
m = ex8(my, lambda v:int(v))
print(m)




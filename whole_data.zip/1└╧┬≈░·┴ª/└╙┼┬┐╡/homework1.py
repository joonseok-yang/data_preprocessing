def bmi(weight, height):
    std = (height - 100) * 0.85
    bmi = (weight/std) * 100
    printdef(bmi)

def printdef(b):
    if b >= 120:
        print('비만')
    elif b > 110:
        print('과체중')
    elif b > 90:
        print('과체중')
    else:
        print('저체중')

# prob1 = [int(x) for x in input('체중 키 입력 :').split()]
# bmi(prob1[0], prob1[1])

def yun(y):
    if y % 4 == 0 and y % 100 != 0 or y % 400 == 0:
        print("윤년")
    else:
        print("윤년아님")
    print("띠 :", jisin(y))
    print("나이 %d" % (2019 - y))

def jisin(y):
    tti = ["원숭이", "닭", "개", "돼지", "쥐", "소", "범", "토끼", "용", "뱀", "말", "양"]
    return (tti[y%12])

# prob2 = int(input("출생년도 입력 :"))
# yun(prob2)

def hakjum(grade):
    a = 0
    jum = {1:'A', 2:'B', 3:'C', 4:'D', 5:'F'}
    if 100>= grade >= 90:
        a = 1
    elif grade >= 80:
        a = 2
    elif grade >= 70:
        a = 3
    elif grade >= 60:
        a = 4
    else:
        a = 5

    print("학점 : ", jum[a])

# prob3 = int(input("점수 입력:"))
# hakjum(prob3)

def mToMile(meter):
    print("마일 : ", meter * 0.000621371)

# prob4 = int(input("Meter 입력:"))
# mToMile(prob4)

# (화씨온도 - 32) ÷ 1.8 = 섭씨온도
def hwaToDegree(hwasi):
    print("섭씨온도 : ", (hwasi -32)/1.8  )

# prob5 = int(input("화씨 입력:"))
# hwaToDegree(prob5)

def yaksu(n):
    print ("약수 :", [ x for x in range(1,n) if n % x == 0])

# prob6 = int(input("정수 입력:"))
# yaksu(prob6)

def absSum(a,b):
    if a < 0:
        a = a * -1

    if b < 0:
        b = b * -1

    print("절대값의 핪 :", a + b)

prob7 = [int(x) for x in input('정수 두 개 입력 :').split()]
absSum(prob7[0], prob7[1])

def mymap(a, b):
    m = []
    for x in range(0, len(b)):
        m.append(a(b[x]))
    print(m)

# my = ['10','20','30']
# mymap(int, my)

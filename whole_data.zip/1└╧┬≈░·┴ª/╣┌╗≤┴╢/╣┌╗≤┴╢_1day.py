# 1. 키와 몸무게를 입력받아 비만도를 구하고 결과를 출력하시요(함수를 만드시요)
# 표준체중(kg)=(신장(cm)-100)×0.85
# 비만도(%)=현재체중/표준체중(%)×100
#
# 비만도가90%이하
# 저체중,
# 90초과~110%
# 정상,
# 110초과~120%
# 과체중,
# 120%초과
# 비만
def weigh(cm):
    return (cm-100) * 0.85

def overweigh(cm,kg):
    return kg / weigh(cm) * 100

height = input('키를 입력해 주세요 : ')
weight = input('몸무게를 입력해 주세요 : ')

cal = overweigh(int(height),int(weight))

if cal <= 90:
    print('저체중')
elif 90< cal <= 110:
    print('정상')
elif 100< cal <= 120:
    print('과체중')
elif 120< cal:
    print('비만')

#
# 2. 년도 입력받아
# 1) 윤년여부를 출력하시요
# 윤년의 조건
# 1-1) 4로 나눠 떨어지지만 100으로 나눠 떨어지지 않아야 한다 또는
# 1-2) 400 으로 나눠 떨어지면 윤년임
# 2) 나이를 출력하시요
# 3) 띠(12지신)를 출력하시요
def check(n):
    if (n%4 == 0 and n%100 != 0) or n%400 == 0:
        print('윤년')
    else:
        print('윤년이 아님')

n = int(input("연도를 입력해 주세요: "))
check(n)

# 3. 점수를 입력받아
# 90~100 'A'
# 80~89 'B'
# 70~79 'C'
# 60~69 'D'
# 나머지 'F'
# 딕셔너리를 이용하여 구하시요
def score(n):
    if 90<= n <= 100:
        print('A')
    elif 80<= n <= 89:
        print('B')
    elif 70<= n <= 79:
        print('C')
    elif 60<= n <= 69:
        print('D')
    else:
        print('F')

n = input ('점수를 입력해 주세요 : ')
score(int(n))

# 4. m 를 입력받아 마일로 변환하시요(함수를 만드시요)
def change(m):
    print(m/1609.344)

m = input('m를 입력해 주세요: ')
change(int(m))

# # 5. 화씨 를 입력받아 도로 변환하시요(함수를 만드시요)
def tempchange(t):
    print((t - 32) * 5/9)

t = input('화씨를 입력해 주세요: ')
tempchange(int(t))

# 6. 하나의 정수를 입력받아 약수를 구하는 함수를 만드시요.
def yaksu(n):
    i = 1
    y = []
    while i<=n:
        if n%i == 0:
          y.append(i)
        i+=1
    print('약수는 : ', y)

n = input('정수를 입력해 주세요: ')
yaksu(int(n))

# 7. 2개의 정수를 입력받아 절대값의 합을 구하는 함수를 만드시요
def absum(n,m):
    print('절대값의 합', abs(n) + abs(m))

n1 = input('첫번째 숫자를 입력: ')
n2 = input('두번째 숫자를 입력: ')

absum(int(n1),int(n2))

# 8. map 함수와 동일한 기능을 하는 mymap 함수를 구현하시요.
#
#
#
#

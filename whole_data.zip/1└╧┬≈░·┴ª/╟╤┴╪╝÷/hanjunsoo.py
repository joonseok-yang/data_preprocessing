# 과제1
height=input('키(cm)를 입력해 주세요:')
height=int(height)
weight=input('몸무게(kg)를 입력해 주세요:')
weight=int(weight)

stdWeight=(height-100)*0.85
BMI=weight/stdWeight*100

if BMI<=90:
    print('저체중')
elif 90<BMI<=110:
    print('정상')
elif 110<BMI<=120:
    print('과체중')
else:
    print('비만')

# 과제2
year=input('태어난 해를 입력해 주세요(예. 1988):')
year=int(year)

specialYear=0
if year%4==0 and year%100!=0:
    specialYear=1
elif year%400==0:
    specialYear=1
else:
    specialYear=0

# print(specialYear, type(specialYear))
if specialYear==1:
     print("윤년입니다.")
else:
     print("윤년이 아닙니다.")

print("당신의 한국 나이는",2019-year+1,"입니다.")

Zodiac_Names=['Rat', 'Ox', 'Tiger','Rabbit','Dragon','Snake', 'Horse', 'Goat','Monkey','Rooster', 'Dog', 'Fig']
zodiacNo=year%12-4
print("당신의 띠는",Zodiac_Names[zodiacNo],"입니다.")

# 과제3
score=input("점수를 입력해 주세요:")
score=int(score)

grade=['A','B','C','D','F']
print("당신의 학점은", end='')
if 90<=score<=100:
    print(grade[0],end=' ')
elif 80<=score<90:
    print(grade[1],end=' ')
elif 70<=score<80:
    print(grade[2],end=' ')
elif 60<=score<70:
    print(grade[3],end=' ')
else:
    print(grade[4],end=' ')
print('입니다.')

# 과제4
def mTomile(a):
    return a*0.000621371

print('단위 환산 : 3m 는', mTomile(3),'mile 입니다.')

# 과제5
def FahrenToCelcius(b):
    return (b-32)*(5/9)

print('온도 환산 : 32F는',FahrenToCelcius(32),'도입니다.')

# 과제6
number=int(input('숫자(정수)를 입력해 주세요:'))
divisors = []
divisors.append(number)
h_number=int(number/2)
while h_number>=1:
    if number%h_number==0:
        divisors.append(h_number)
    h_number-=1

print(divisors)

# 과제7
def hab(a,b):
    if a<0:
        a=-a
    if b<0:
        b=-b
    return a+b

a=int(input('첫번째 정수를 입력하세요:'))
b=int(input('두번째 정수를 입력하세요:'))
print('입력한 두 정수의 합은',hab(a,b),'입니다.')

# 과제8
def mymap(a,b,c,d,e):
    gain=(a-b)/(a-c)
    return (e-d)*gain

print(mymap(3,1,5,0,100))


# map(value, fromLow, fromHigh, toLow, toHigh);
# 매개변수(Parameters)
# value : 매핑하고자 하는 값
# fromLow : 현재 범위의 하한값
# fromHigh : 현재 범위의 상한값
# toLow : 매핑하고자 하는 범위의 하한값
# toHigh : 매핑하고자 하는 범위의 상한값

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False

mysr = pd.Series()


print("제품수량관리")
print("--------------")
print("1.입력")
print("2.출력")
print("3.검색")
print("4.정렬(제품명기준)")
print("5.차트보기(바차트)")
print("6.종료")
a = input("메뉴를 선택하세요:")






while a > 6 :
if a == 1:
    c = input ("제품값")
    b = input("입력값:")
    mysr[c] = b
    print(mysr)


elif a == 2:
    print(mysr)

elif a == 3:
    d = input("검색할 이름을 적으세요:")
    print(mysr[d])


elif a==4:
    mysr.sort_index(ascending=True)
    print(mysr)


elif a == 5:
    mysr.plot(kind='bar')
    plt.show()


elif a == 6:
    print('bye')

else :
    print('not Key')

#1
def weight ():
    a = input ('키:')
    b = input ('몸무게:')
    a = int(a)
    b = int(b)
    kg = (a-100)*0.85
    print (kg)
    we = b/((a-100)*0.85) *100


    if we < 90 :
        print('저체중')
    elif 90 < we < 110:
        print('정상')
    elif 110 < we <120:
        print('과체중')
    else :
        print ('비만')

# weight()

#2
def year ():
    c = input('올해 년도:')
    c = int(c)
    if c%4 ==0 and c%100!=0 :
        print('윤년')
    elif c%400 == 0 :
        print ('윤년')
    else :
        print('윤년아님')

    d = 2019 - c
    print(d)


# year()

#3
def jumsu():
    f = input('점수:')
    f = int(f)
    if 90 <= f <=100:
        print('A')
    elif 80 <= f <90:
        print('B')
    elif 70 <= f <80:
        print('C')
    elif 60 <= f <70:
        print('D')
    else:
        print('F')

# jumsu()

#4
def mtomile():
    g = input('미터:')
    g = float(g)

    mile = g /  1609.344
    print(mile)

# mtomile()

#5
def ctof():
    h = input('썹씨:')
    h = float(h)

    F = (h*(9/5)) + 32
    print(F)

# ctof()
#6
def yaksu():
    y= input('정수: ')
    y = int(y)

    for i in range(1, y+1):
        if y%i==0:
            print(i)

# yaksu()

#7
def double():
    a = int(input('첫번째 숫자:'))
    if a >=0 :
        a = a
        print(a)
    else :
        a = -a
        print(-a)

    b = int(input('두번째 숫자:'))
    if b >=0:
        b = b
        print(b)
    else :
        b = -b
        print(-b)

    c = a+b
    print(c)

# double()

#8
# def mymap():





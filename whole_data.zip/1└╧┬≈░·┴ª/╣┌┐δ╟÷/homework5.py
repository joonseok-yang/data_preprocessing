def FtoC(a):
    return (a-32)/1.8

fahren = int(input('enter the fahrenheit degree'))

print('Caculated Celsius degree is ',FtoC(fahren),'degree')

import datetime

birth_year = int(input('enter the birth year'))


if ((birth_year%4.==0 and birth_year%100.!=0) or (birth_year%400.==0)):
    print ('your birthday is yoon-nen')
else:
    print ('your birthday is not yoon-nen')

this_year=datetime.datetime.today()
print(list(this_year),type(this_year))

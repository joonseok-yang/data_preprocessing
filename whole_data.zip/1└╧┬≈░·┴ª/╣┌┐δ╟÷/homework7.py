def abs_sum(a,b):
    return abs(a)+abs(b)


num1 = int(input('enter the number1'))
num2 = int(input('enter the number1'))

print('ABS sum is',abs_sum(num1,num2))

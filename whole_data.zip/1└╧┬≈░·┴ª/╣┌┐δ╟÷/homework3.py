def table(score)
    if 90<=score<100:
        return a



score = int(input('enter the score'))

level={1:fn, 2:fn1}

d.get(3,defaultFn)()

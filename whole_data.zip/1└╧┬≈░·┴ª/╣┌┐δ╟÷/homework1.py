def normal_weight(a):
    return (a-100)*0.85

def fat_ratio(a,b):
    return b/((a-100)*0.85)*100

height = int(input('enter the height(cm)'))
weight = int(input('enter the weight'))

print('Caculated normal weight is',normal_weight(height),'kg')

result=fat_ratio(height,weight)
print('Caculated fat ratio is',result,'%')

if result<=90 :
    print('This is low fat')
elif 90<result<=110:
    print('This is normal fat')
elif 110<result<=120:
    print('This is high fat')
else:
    print('This is too much fat')

def meterTomile(a):
    return 0.000621*a

meter = int(input('enter the meter(m)'))

print('Caculated mile is',meterTomile(meter),'mile')

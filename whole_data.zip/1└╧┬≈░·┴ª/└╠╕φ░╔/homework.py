#1
def regw(h):
    return (h-100)*0.85

def bimando(h, w):
    return (w/regw(h))*100

def hw1():
    rst = bimando(int(input('키:')),int(input('몸무게:')))

    if rst <= 90:
        print('저체중')
    elif 90 < rst <= 110:
        print('정상')
    elif 110 < rst <= 120:
        print('과체중')
    else:
        print('비만')

hw1()

#2
def enteryear ():
    return int(input('년도:'))

def yunyear ():
    y = enteryear()
    if y % 4 == 0 and not y%100==0:
        print ('윤년')
    elif y % 400 == 0:
        print ('윤년')
    else:
        print ('윤년아님')
def hw2():
    yunyear()
    # def 나이 /띠

hw2()

#3
def fna() :
    print('A')
def fnb() :
    print('B')
def fnc() :
    print('C')
def fnd() :
    print('D')
def fnf() :
    print('F')

def hw3():
    d = {0:fnd, 1:fnc, 2:fnb, 3:fna, 4:fna}
    rst = int(input('점수:'))//10 - 6
    d.get(rst,fnf)()

hw3()


#4
def mtomile(m):
    return m * 0.000621

def enterm():
    return int(input('미터를 입력하세요:'))

def hw4() :
    print (mtomile(enterm()))

hw4()

#5
def ftoc(f):
    return f - 17.777
def enterf():
    return float(input('화씨를 입력하세요:'))
def hw5() :
    print (ftoc(enterf()))

hw5()

#6
def enternum():
    return int(input('정수를 입력하세요:'))

# def yak (n)
#     return for n range(1,n) if n
#







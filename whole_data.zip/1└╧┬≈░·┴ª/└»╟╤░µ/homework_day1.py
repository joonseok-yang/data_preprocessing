#1. 키와 몸무게를 입력받아 비만도를 구하고 결과를 출력하시요(함수를 만드시요)
#   표준체중(kg)=(신장(cm)-100)×0.85
#   비만도(%)=현재체중/표준체중(%)×100
#
n = input('키:')
tall = int(n)
n = input('몸무게:')
weight = int(n)

a = (tall - 100)*0.85
b = (weight / a) * 100

print(b)
if b > 120:
    print('비만')
elif 120 >= b > 110:
    print('과체중')
elif 110 >= b > 90:
    print('정상')
else:
    print('저체중')

print('============================================')
# 2. 년도 입력받아
# 1) 윤년여부를 출력하시요
# 윤년의 조건
# 1-1) 4로 나눠 떨어지지만 100으로 나눠 떨어지지 않아야 한다 또는
# 1-2) 400 으로 나눠 떨어지면 윤년임
n = input('연도:')
year = int(n)
if year%400 == 0:
    print('윤년')
else:
    print('평년')

# 2) 나이를 출력하시요???
n2 = input('출생연도:')
birth = int(n2)
print(year - birth + 1)

# 3) 띠(12지신)를 출력하시요???
# 2008이 자
# 자축인묘진사오미신유술해
s = '자축인묘진사오미신유술해'
print(s[year%12])

print('============================================')
# 3. 점수를 입력받아
# 90~100 'A'
# 80~89 'B'
# 70~79 'C'
# 60~69 'D'
# 나머지 'F'
# 딕셔너리를 이용하여 구하시요')

d = {'A':90, 'B':80, 'C':70, 'D':60, 'F':50}

n = input('점수:')
point = int(n)

if point >= d['A']:
    print('A')
elif d['A'] > point >= d['B']:
    print('B')
elif d['B'] > point >= d['C']:
    print('C')
elif d['C'] > point >= d['D']:
    print('D')
else:
    print('F')

print('============================================')
# 4. m 를 입력받아 마일로 변환하시요(함수를 만드시요)')
def mTomile(a):
    return a*1.6

n = input('미터:')
meter = int(n)

print(mTomile(meter))


print('============================================')
#print('5. 화씨 를 입력받아 도로 변환하시요(함수를 만드시요)')
def fToc(a):
     return ((a-32)*5)/9

n = input('화씨:')
cep = int(n)

print(fToc(cep))

print('============================================')
# 6. 하나의 정수를 입력받아 약수를 구하는 함수를 만드시요.')

def calc(n):
    a=1
    max=int(n/2)
    while a<=max:
        if (n%a) == 0:
            print(a)
        a+=1


n = input('정수:')
number = int(n)
calc(number)

print('============================================')
#7. 2개의 정수를 입력받아 절대값의 합을 구하는 함수를 만드시요')
n1 = int(input('첫번째 정수:'))
n2 = int(input('두번째 정수:'))

def absum(a,b):
        return abs(a) + abs(b)

print(absum(n1,n2))


print('============================================')
# 8. map 함수와 동일한 기능을 하는 mymap 함수를 구현하시요.')
data=[10,20,30,40,50]

def mymap(*args):
    return map(*args)

m = mymap(lambda v:v+2, data)
print(list(m))



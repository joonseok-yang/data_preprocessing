
# 1
def num1():
    h=int(input('키:'))
    w=int(input('몸무게:'))
    rst=w*100/((h-100)*0.85)
    print('표준체중:%d 비만도:%d'%((h-100)*0.85,rst))

    if rst <= 90:
        print('저체중')
    elif rst <= 110:
        print('정상')
    else:
        print('비만')
#2
def num2():
    thisyear=int(input('year:'))
    if thisyear%4==0 and thisyear%100!=0 or thisyear%400==0:
        print('윤년임')
    else:
        print('윤년아님')
    print('nai:',2019-thisyear+1)
    rst=thisyear%12
    d={1:'a',2:'b',3:'c',4:'d',5:'e',6:'f',7:'g',8:'h',9:'i',10:'j',11:'k',12:'l'}
    print('myddi:',d[rst])
#3
def num3():
    s=int(input('score:'))
    s1=s//10
    d={10:'A',9:'A',8:'B',7:'C',6:'D'}
    print(d.get(s1,'F'))

#4
def num4():
    s=int(input('M:'))
    return s*0.000621371
#5
def num5():
    s=int(input('temp:'))
    return (s-32)*5/9
#6
def num6():
    s=int(input('number:'))
    return [n for n in range(1,s+1) if s%n==0]

#7
def num7():
    n1=int(input('n1:'))
    n2=int(input('n2:'))
    return abs(n1)+abs(n2)
#8
def mymap(abcd,fn):
    newlist=[]
    for a in abcd:
        newlist.append(fn(a))
    return newlist

print(mymap([1,2,3],lambda v:v*10,))


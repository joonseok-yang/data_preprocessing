# 1. 키와 몸무게를 입력받아 비만도를 구하고 결과를 출력하시요(함수를 만드시요) - done
# 표준체중(kg)=(신장(cm)-100)×0.85
# 비만도(%)=현재체중/표준체중(%)×100

# 비만도가90%이하
# 저체중,
# 90초과~110%
# 정상,
# 110초과~120%
# 과체중,
# 120%초과
# 비만

# def fn(per):
#     if per <= 90:
#         print('저체중')
#     elif 90<per <= 110:
#         print('정상')
#     elif 110<per <= 120:
#         print('과체중')
#     elif 120<per:
#         print('비만')
#
# in1 = input('키:')
# in2 = input('몸무게:')
# height = int(in1)
# weight = int(in2)
# stdweight = (height - 100) * 0.85
# print( '표준체중:' + str( stdweight ))
# fn(weight / stdweight * 100)



# 2. 년도 입력받아        - done
# 1) 윤년여부를 출력하시요
# 윤년의 조건
# 1-1) 4로 나눠 떨어지지만 100으로 나눠 떨어지지 않아야 한다 또는
# 1-2) 400 으로 나눠 떨어지면 윤년임
# 2) 나이를 출력하시요
# 3) 띠(12지신)를 출력하시요

# data = '자축인묘진사오미신유술해'
# syear = input('년도:')
# nyear = int(syear)
# isYoon = nyear%400==0
# age = 2019 - nyear + 1
# ddi = data[(nyear+8)%12]
# print('윤년:' + str(isYoon) + ',  나이:' + str(age) + ',  띠:' +  ddi)

# 3. 점수를 입력받아
# 90~100 'A'
# 80~89 'B'
# 70~79 'C'
# 60~69 'D'
# 나머지 'F'
# 딕셔너리를 이용하여 구하시요

def fn1():
    print('A')
def fn2():
    print('B')
def fn3():
    print('C')
def fn4():
    print('D')
def fn5():
    print('F')

sscore = input('점수:')
nscore = int(sscore)
d={10:fn1, 9:fn1, 8:fn2, 7:fn3, 6:fn4, 5:fn5, 4:fn5, 3:fn5, 2:fn5, 1:fn5, 0:fn5}
d[nscore//10]()

# 4. m 를 입력받아 마일로 변환하시요(함수를 만드시요)    - done

# def mToMile(meter):
#     return meter * 0.000621
# smeter = input('미터:')
# nmeter = int(smeter)
# print('마일:' + str(mToMile(nmeter)))

# 5. 화씨 를 입력받아 도로 변환하시요(함수를 만드시요)    - done
# (F-32) / 1.8

# sf = input('화씨:')
# nf = int(sf)
# c = (nf-32)/1.8
# print('도:' + str(c))

# 6. 하나의 정수를 입력받아 약수를 구하는 함수를 만드시요.  - done

# sn = input('정수:')
# nn = int(sn)
# yaksu = [n for n in range(1,nn+1) if nn%n==0]
# print(yaksu)


# 7. 2개의 정수를 입력받아 절대값의 합을 구하는 함수를 만드시요   - done
# in1 = input('정수1:')
# in2 = input('정수2:')
# n1 = int(in1)
# n2 = int(in2)
# an1 = n1 if n1>=0 else n1*(-1)
# an2 = n2 if n2>=0 else n2*(-1)
# print('절대값의 합:' + str(an1 + an2))

# 8. map 함수와 동일한 기능을 하는 mymap 함수를 구현하시요.
# my = ['10','20','30']
# # m = map( lambda v:int(v),my)
# m = map( int,my)
#
# def mymap()

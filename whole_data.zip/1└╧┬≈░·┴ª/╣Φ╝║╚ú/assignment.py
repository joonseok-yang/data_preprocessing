import datetime

def howfat(cm, kg):
    stdkg = (cm - 100) * 0.85
    ratio = kg / stdkg * 100
    if ratio <= 90:
        return "저체중"
    if ratio <= 110:
        return "정상"
    if ratio <= 120:
        return "과체중"
    return "비만"

def isluna(year):
    if year % 4 == 0 and year % 100 != 0:
        return True
    if year % 400 == 0:
        return True
    return False

def age(year):
    return datetime.datetime.now().year - year

def zodiac(year):
    seg10 = ['경', '신', '임', '계', '갑', '을', '병', '정', '무', '기']
    seg12 = ['신', '유', '술', '해', '자', '축', '인', '묘', '진', '사', '오', '미']
    return seg10[year%10] + seg12[year%12]

def grade(score):
    d = {}
    for k in range(90, 101):
        d[k] = 'A'
    for k in range(80, 90):
        d[k] = 'B'
    for k in range(70, 80):
        d[k] = 'C'
    for k in range(60, 70):
        d[k] = 'D'
    return d.get(score, 'F')

def mile(meter):
    return meter * 0.000621371

def celsius(f):
    return (f - 32) * 5.0 / 9

def divisor(n):
    return [ d for d in range(1, n + 1) if n % d == 0 ]

def abssum(a, b):
    a = a if a >= 0 else -a
    b = b if b >= 0 else -b
    return a + b

def mymap(func, iter):
    return [func(x) for x in iter]

def p1():
    cm = float(input("키: "))
    kg = float(input("체중: "))
    print("비만도:", howfat(cm, kg))

def p2():
    year = int(input("년도: "))
    print("윤년여부:", isluna(year))
    print(f"나이: 만 { age(year) } 세")
    print(f"띠: { zodiac(year) }년")

def p3():
    score = int(input("점수: "))
    print("등급:", grade(score))

def p4():
    meter = float(input("미터: "))
    print("마일:", mile(meter))

def p5():
    f = float(input("화씨: "))
    print("섭씨:", celsius(f))

def p6():
    num = int(input("약수를 구할 숫자: "))
    print("약수:", divisor(num))

def p7():
    a, b = map(int, input("합을 위한 두 정수: ").split())
    print("절대합:", abssum(a, b))

def p8():
    arr = input("숫자 배열 입력: ").split()
    print("원본:", arr)
    print("map:", list(map(int, arr)))
    print("mymap:", mymap(int, arr))

def main():
    p1()
    p2()
    p3()
    p4()
    p5()
    p6()
    p7()
    p8()

if __name__ == '__main__':
    main()

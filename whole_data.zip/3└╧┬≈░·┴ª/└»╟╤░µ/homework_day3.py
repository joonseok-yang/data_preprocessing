import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import warnings
matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')

df = pd.read_csv('CCTV_in_Seoul.csv', index_col='기관명', encoding='utf-8')
df

#1. 2014년, 15년에 대한 바차트를 그리시오
df[['2014년','2015년']].plot(kind='bar')
plt.show()

#2. cctv 소계가 가장 많은 top5 기관명(2014년 기준)
df.sort_values(by='소계')[:5]

#3.최근 2년동안 cctv 증가율을 구하시오
df['2015년의 증가율'] = ((df['2015년'] / (df['2013년도 이전'] + df['2014년'])) * 100)
df['2016년의 증가율'] = ((df['2016년'] / (df['2013년도 이전'] + df['2014년'] + df['2015년'])) * 100)
df


# 4. cctv 소계 1000이상은 높음, 미만은 낮음으로 설치 정도 컬럼 추가하시오
df['설치 정도'] =  df['소계'].apply(lambda v:'높음' if v>1000 else '낮음')
df

# 5. 2016년 cctv 수가 가장 높은 기관명의 2015년 cctv수, 2014년 cctv 수를 출력하시오
df.sort_values(by='2016년', ascending=False)[['2015년','2016년']][:1]

# 6. 2013년도 이전과 2016년의 cctv 증가율 col을 생성
# 증가율이 1.2 이상이면 '급증', 1 이상이면 '보통', 그 외엔 '낮음' 컬럼 생성
temp = ((df['2016년'] + df['2014년'] + df['2015년']) / (df['2013년도 이전']))
temp
df['cctv 증가율'] = temp.apply(lambda v:'급증' if v >= 1.2 else '보통' if v >= 1 else '낮음')
df


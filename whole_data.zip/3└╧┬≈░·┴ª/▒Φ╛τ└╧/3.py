import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import warnings

matplotlib.rcParams['font.family']='Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus']=False
warnings.simplefilter('ignore')

df = pd.read_csv(r'd:\CCTV_in_Seoul.csv', encoding='utf-8', index_col='기관명')

df[['2014년', '2015년']].plot(kind='bar', figsize = (15, 4))
plt.show()

df.sort_values(by='2014년', ascending=False).head()

df['CCTV설치수'] = df['2013년도 이전'] + df['2014년'] + df['2015년'] + df['2016년']

df['설치 정도'] = df['소계'].apply(lambda v: '높음' if v >= 1000 else '낮음')

df [ df['2016년'] == df['2016년'].max()][['2015년', '2016년']]

(df['2016년'] + df['2015년']) / df['CCTV설치수'] * 100
df['2013년도 이전과 2016년의 cctv 증가율'] = ((df['CCTV설치수'] - df['2013년도 이전']) / df['2013년도 이전']).apply(lambda v: '급증' if v >= 1.2 else ('보통' if v >= 1.0 else '낮음'))



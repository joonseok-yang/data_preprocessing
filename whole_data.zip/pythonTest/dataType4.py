s1 ='abc\n\t\tdef'
s2 ="abc" \
    "def"
s3 ='''abc
        def'''
s4 ="""abc
def"""
print(s1)
print(type(s1))
print(s2)
print(type(s2))
print(s3)
print(type(s3))
print(s4)
print(type(s4))

data=[10,20,30,40,50]
f = filter(lambda v:v>30,data)
print( list(f) )
m = map(lambda v:v+2, data)
print( list(m) )
my = ['10','20','30']
# m = map( lambda v:int(v),my)
m = map( int,my)
print(list(m))

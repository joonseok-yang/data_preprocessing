s='abc'
my =[10,20,30]
d ={'aa':10,'bb':20,'cc':30}
for n in s:
    print(n)
for n in my:
    print(n)
for n in d: #d.keys()
    print(n)
for n in d.values():
    print(n)
for n in d.items():
    print(n)
for k,v in d.items():
    print(k,v)


# for 변수 in 복합데이터타입:
# a= 1
# while a<=5:
#     print(a)
#     a+=1

t = (10,20,30,40,50)
# print(t)
# print(type(t))
# print(t[0])
# print(t[1:4])
# t[0] = 100 #X
# a=10;b=20;c=30
# a,b,c = 10,20,30
t1 =10,20,30 #packing..(tuple로 자동변환)
print(t1)
n1,n2,n3 =[5,6,7] #(5,6,7) #unpaking
print(n1,n2,n3)

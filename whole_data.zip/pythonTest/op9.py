#range(시작값,끝값, 증가치)
# 시작값<= n <끝값  해당리스트
r = range(1,5,1) #1<= n <5
print( list(r) )
r = range(1,5,2) #1<= n <5
print( list(r) )
r = range(1,5) #1<= n <5
print( list(r) )
r = range(5) #0<= n <5
print( list(r) )
for n in range(1,6):
    print(n)

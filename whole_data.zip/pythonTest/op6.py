# int a=5;
# int rst;
# rst = a>0? 100 : 200
a=5
rst = 100 if a>0 else 200
print(rst)


d={'a':1,'b':2,'c':3}
print( d.keys())
print( d.values())
print( d.items() )
print( d.get('a',0)) #d['a']
print( d.get('f',0)) #d['a']
d.pop('b')
print(d)
# d['b'] =20 #수정
# d['d'] = 4 #추가
# print(d)
# print(type(d))
# print(d['a'])


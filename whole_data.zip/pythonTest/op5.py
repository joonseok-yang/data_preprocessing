a=5
b = None
#모두 True
# rst = a>0 and a==0
#모두 False ==>False
# rst = a>0 or a==0
# rst = not a>0
rst = not [10]
print(rst)
# 0, None, '', [], {}  ==>False
# 2,3.14, 'abc',[10],{'a':10} ==>True
my = [10,20,30]
print( 100 in my ) # 요소값 in 복합데이터타입
print( 100 not in my )
s ='hello korea'
d = {'a':10,'b':20}
print( 'llo' in s)
print('a' in d)
print(10 in d.values())


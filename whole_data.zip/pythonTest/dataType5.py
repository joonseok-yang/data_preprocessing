s1 = '  abc  '
s2 = '###abc###'
s3 = 'abc def ghi'
s4 = 'abc-def-ghi'
s5 ='abcdefghi'
#    012345 6 7 8
#       ...-3-2-1
print( s5[0] )
print( s5[1] )
print( s5[-1] )
print( s5[-2] )
#slicing [시작인덱스:끝인덱스:증가치]
#시작인덱스<= idx <끝인덱스
print( s5[1:4:1])#1<=idx<4  1,2,3
print( s5[1:5:2])#1<=idx<5 1,2,3,4
print( s5[1:4]) #증가치 디폴트1
print( s5[1:])
print( s5[:4]) #0<=  <4
print( s5[-1:-4:-1])#-1,-2,-3
print( s5[:-5:-1]) #디폴트 -1
print(s5[::-1])
print(s5[1:-1])

#white space(' ',\n,\t,\r)
# print( s1.strip() )
# print( s2.strip('#'))
# print( s3.split() )
# print( s4.split('-') )

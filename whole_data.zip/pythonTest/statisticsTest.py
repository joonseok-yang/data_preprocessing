from statistics import mean,median,stdev
data=[(10,20),(30,80),(50,60)]
data1=[{'kor':70,'eng':90},{'kor':50,'eng':40}]
# my =[n for n in data if n[0]>=30]
f =filter(lambda v:v[0]>=30, data)
print(list(f))
f1 =filter(lambda v:v['kor']>=60, data1)
print(list(f1))
m = map(lambda v:v[0]+2, data)
print(list(m))
print( max(10,20,30))
print( max(data,key=lambda v:v[0]) )
print( max(data1,key=lambda v:v['eng']) )
rst = sorted(data,key=lambda v:v[0],reverse=True)
print( rst )

print( sum( [10,20,30] ))
print( mean( [10,20,30] ))
print( median( [10,20,30] ))
print( stdev( [10,20,30] ))
print( sum( [ n[0] for n in data] ) )
print( mean( [ n[0] for n in data] ) )


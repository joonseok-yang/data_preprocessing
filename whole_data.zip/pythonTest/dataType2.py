f = 3.0
f1 = 3.141592e-3
print( f.is_integer() )
print(f)
print(type(f))
print(f1)

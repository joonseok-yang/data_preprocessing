s ='abc'
# s = s+'def'
s = s*3
print(s)
a=10
f=3.14
s1='korea'
s2 = 'a=%10d f=%.2f s=%s'%(a,f,s1)
print(s2)
s3 = f'a={a} f={f} s={s1}' #3.5 이후지원
print(s3)

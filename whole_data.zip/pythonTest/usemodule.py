# import mymodule as m #py,pyc, pyd
# from mymodule import hap,gop
from mymodule import *
import sys
#python -m py_compile mymodule.py
#p
# sys.path.append("d:\mypath")
# print(sys.path)

rst = hap(10,20)
print(rst)

rst = gop(10,20)
print(rst)

# rst = m.hap(10,20)
# print(rst)
#
# rst = m.gop(10,20)
# print(rst)

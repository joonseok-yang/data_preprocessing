s = {10,20,30,40,50,20,20}
s.add(60)
# s.pop()
s.remove(30)
print(s)
print(type(s))

# print(s[0])  X

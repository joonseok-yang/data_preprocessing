a= 15
# rst = a>0
# rst = a<0
# rst = a>=0
# rst = a<=0
# rst = a==0
# rst = a!=0
rst = 0< a < 10 #c 0<a && a<10
print(rst)

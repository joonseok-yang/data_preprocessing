from mymath import circle, danwi
print(circle.circle_area(3))
print(danwi.cmToinch(3))

# import mymath.circle as c
# from mymath.circle import circle_area,cylinder
# import mymath.danwi as d
#
# print( circle_area(4) )
# print( cylinder(4,10) )
# print( d.cmToinch(3) )

# print( c.circle_area(4) )
# print( c.cylinder(4,10) )
# print( d.cmToinch(3) )

# print( mymath.circle.circle_area(4) )
# print( mymath.circle.cylinder(4,10) )
# print( mymath.danwi.cmToinch(3) )


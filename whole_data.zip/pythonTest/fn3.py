
def fn():
    print('fn...')

def my( aa ):
    aa()

def my1():
    return fn
# my( fn )
rst = my1()
rst()

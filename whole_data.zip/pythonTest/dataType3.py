b = True #False
print(b)
print( type(b))

r = input('반지름:')
r = int(r)
circleArea= r**2*3.14
print(circleArea)

# n = input('입력:')
# print(n, type(n))
#
# a = 10
# a = str(a)
# s = '100'
# s = int(a)
# print(s)

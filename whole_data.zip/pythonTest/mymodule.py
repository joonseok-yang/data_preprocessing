def hap(a,b):
    return a+b

def gop(a,b):
    return a*b

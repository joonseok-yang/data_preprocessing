a=5
# rst = a**2
# rst = a*2
# rst = a/2
# rst = a%2
# rst = a//2
# rst = a + 2
# rst = a - 2
# rst =  3*2**2+3-2
# print(rst)
# a = a**2
a **=2
print(a)
# a++ (X)


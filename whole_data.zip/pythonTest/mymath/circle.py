def circle_area(r):
    return r**2*3.14

def cylinder(r,h):
    return r**2*3.14*h

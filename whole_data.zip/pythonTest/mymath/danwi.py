def cmToinch(cm):
    return cm*0.393701

my = [n*10 for n in range(1,6)]
print(my)
my = [n*10 for n in range(1,6) if n%2==0]
print(my)
#세금3.3을제한 실수령금액에 대한 리스트를
# 만드시요
salary = [1000,2000,3000,4000,5000]
sil = [ n*(1-0.033) for n in salary]
print(sil)

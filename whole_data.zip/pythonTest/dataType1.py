#ctrl+f5 (shift+f10)
# ctrl + /
#객체  (속성, 메소드)
# 객체.속성
# 객체.메소드(..)
a = 10
b = 1902347129341279412734912
print(a)
print(type(a))
print(b)
